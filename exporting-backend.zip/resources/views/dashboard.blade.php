@extends('layouts.app')
@push('title')
    Dashboard
@endpush
@section('content')

@endsection
